import java.util.Scanner;


	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("enter the first value:");
		int a=scanner.nextInt();
		System.out.print("enter the second value:");
		int b=scanner.nextInt();
		
		int sum = a+b;
		int difference = a-b;
		int product = a*b;
		
		System.out.println("result:");
		System.out.println("sum" +sum);
		System.out.println("difference" + difference);
		System.out.println("product:" + product);
		
	}
