/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
public static void main (String[] args) {
    int a=10;
    int b=20;
    int c=25;
    System.out.println(a>b&&a<c);
    System.out.println(a<b&&a>c);
    System.out.println(a>b||a<c);
    System.out.println(a<b||a>c);
    System.out.println(!(a<b&&a>c));
    System.out.println(!(a<b||a>c));
} 
}