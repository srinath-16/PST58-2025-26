import java.util.Scanner;

public static void main (String[] args) {
    Scanner scanner=new Scanner(System.in);
    
    System.out.println("enter the first number:");
    int a=scanner.nextInt();
    
    System.out.println("enter the second number:");
    int b=scanner.nextInt();
    
    int sum= a+b;
    int difference=a-b;
    int product=a*b;
    
    System.out.println("results");
    System.out.println("sum"+sum);
    System.out.println("difference"+difference);
    System.out.println("product"+product);


}
