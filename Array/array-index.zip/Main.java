/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		//int arr[]=new int [5];
	   int	arr[]={1,2,3,4,5};
	   for(int i=0;i<=4;i++){
		System.out.println(arr[i]);
	   }
	}
}